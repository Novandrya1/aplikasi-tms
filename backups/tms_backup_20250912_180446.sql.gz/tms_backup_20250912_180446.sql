--
-- PostgreSQL database dump
--

\restrict jeyZuEktfC5i1j9A6aZVfvRXParY2M8lqGKvpK9XKFfs4tzElBsIA6NFD0YvGPx

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.drivers (
    id integer NOT NULL,
    user_id integer,
    license_number character varying(50) NOT NULL,
    license_expiry date NOT NULL,
    status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    license_type character varying(20) DEFAULT 'B2'::character varying NOT NULL,
    phone character varying(20),
    address text,
    emergency_contact character varying(100),
    emergency_phone character varying(20)
);


ALTER TABLE public.drivers OWNER TO tms_user;

--
-- Name: drivers_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.drivers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drivers_id_seq OWNER TO tms_user;

--
-- Name: drivers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.drivers_id_seq OWNED BY public.drivers.id;


--
-- Name: fleet_owners; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.fleet_owners (
    id integer NOT NULL,
    user_id integer,
    company_name character varying(255),
    business_license character varying(100),
    address text,
    phone character varying(20),
    verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fleet_owners OWNER TO tms_user;

--
-- Name: fleet_owners_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.fleet_owners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fleet_owners_id_seq OWNER TO tms_user;

--
-- Name: fleet_owners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.fleet_owners_id_seq OWNED BY public.fleet_owners.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(50) DEFAULT 'info'::character varying,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notifications OWNER TO tms_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO tms_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: revenue_records; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.revenue_records (
    id integer NOT NULL,
    fleet_owner_id integer,
    vehicle_id integer,
    trip_date date NOT NULL,
    distance numeric(10,2),
    revenue numeric(12,2) NOT NULL,
    expenses numeric(12,2) DEFAULT 0,
    profit numeric(12,2) GENERATED ALWAYS AS ((revenue - expenses)) STORED,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.revenue_records OWNER TO tms_user;

--
-- Name: revenue_records_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.revenue_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.revenue_records_id_seq OWNER TO tms_user;

--
-- Name: revenue_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.revenue_records_id_seq OWNED BY public.revenue_records.id;


--
-- Name: trip_tracking; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.trip_tracking (
    id integer NOT NULL,
    trip_id integer,
    latitude numeric(10,8) NOT NULL,
    longitude numeric(11,8) NOT NULL,
    speed numeric(5,2),
    heading numeric(5,2),
    accuracy numeric(8,2),
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.trip_tracking OWNER TO tms_user;

--
-- Name: trip_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.trip_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trip_tracking_id_seq OWNER TO tms_user;

--
-- Name: trip_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.trip_tracking_id_seq OWNED BY public.trip_tracking.id;


--
-- Name: trips; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.trips (
    id integer NOT NULL,
    driver_id integer,
    vehicle_id integer,
    origin character varying(255) NOT NULL,
    destination character varying(255) NOT NULL,
    departure_time timestamp without time zone,
    arrival_time timestamp without time zone,
    status character varying(20) DEFAULT 'planned'::character varying,
    distance numeric(10,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    trip_number character varying(50),
    origin_address text,
    destination_address text,
    origin_lat numeric(10,8),
    origin_lng numeric(11,8),
    destination_lat numeric(10,8),
    destination_lng numeric(11,8),
    scheduled_start timestamp without time zone,
    actual_start timestamp without time zone,
    actual_end timestamp without time zone,
    distance_km numeric(10,2),
    fuel_used numeric(8,2),
    cargo_weight numeric(10,2),
    cargo_description text,
    trip_fee numeric(12,2),
    driver_fee numeric(12,2),
    notes text
);


ALTER TABLE public.trips OWNER TO tms_user;

--
-- Name: trips_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.trips_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trips_id_seq OWNER TO tms_user;

--
-- Name: trips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.trips_id_seq OWNED BY public.trips.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    user_type character varying(20) DEFAULT 'customer'::character varying
);


ALTER TABLE public.users OWNER TO tms_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO tms_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicle_attachments; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.vehicle_attachments (
    id integer NOT NULL,
    vehicle_id integer,
    attachment_type character varying(50) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vehicle_attachments OWNER TO tms_user;

--
-- Name: vehicle_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.vehicle_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_attachments_id_seq OWNER TO tms_user;

--
-- Name: vehicle_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.vehicle_attachments_id_seq OWNED BY public.vehicle_attachments.id;


--
-- Name: vehicle_tracking; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.vehicle_tracking (
    id integer NOT NULL,
    vehicle_id integer,
    latitude numeric(10,8),
    longitude numeric(11,8),
    speed numeric(5,2),
    status character varying(50) DEFAULT 'idle'::character varying,
    fuel_level numeric(5,2),
    mileage numeric(10,2),
    last_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.vehicle_tracking OWNER TO tms_user;

--
-- Name: vehicle_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.vehicle_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_tracking_id_seq OWNER TO tms_user;

--
-- Name: vehicle_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.vehicle_tracking_id_seq OWNED BY public.vehicle_tracking.id;


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: tms_user
--

CREATE TABLE public.vehicles (
    id integer NOT NULL,
    registration_number character varying(50) NOT NULL,
    vehicle_type character varying(50) NOT NULL,
    brand character varying(100) NOT NULL,
    model character varying(100) NOT NULL,
    year integer NOT NULL,
    chassis_number character varying(100) NOT NULL,
    engine_number character varying(100) NOT NULL,
    color character varying(50) NOT NULL,
    capacity_weight numeric(10,2),
    capacity_volume numeric(10,2),
    ownership_status character varying(50) NOT NULL,
    operational_status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    insurance_company character varying(100),
    insurance_policy_number character varying(100),
    insurance_expiry_date date,
    last_maintenance_date date,
    next_maintenance_date date,
    maintenance_notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fleet_owner_id integer,
    verification_status character varying(20) DEFAULT 'pending'::character varying
);


ALTER TABLE public.vehicles OWNER TO tms_user;

--
-- Name: vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: tms_user
--

CREATE SEQUENCE public.vehicles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicles_id_seq OWNER TO tms_user;

--
-- Name: vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tms_user
--

ALTER SEQUENCE public.vehicles_id_seq OWNED BY public.vehicles.id;


--
-- Name: drivers id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.drivers ALTER COLUMN id SET DEFAULT nextval('public.drivers_id_seq'::regclass);


--
-- Name: fleet_owners id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.fleet_owners ALTER COLUMN id SET DEFAULT nextval('public.fleet_owners_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: revenue_records id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.revenue_records ALTER COLUMN id SET DEFAULT nextval('public.revenue_records_id_seq'::regclass);


--
-- Name: trip_tracking id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.trip_tracking ALTER COLUMN id SET DEFAULT nextval('public.trip_tracking_id_seq'::regclass);


--
-- Name: trips id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.trips ALTER COLUMN id SET DEFAULT nextval('public.trips_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehicle_attachments id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicle_attachments ALTER COLUMN id SET DEFAULT nextval('public.vehicle_attachments_id_seq'::regclass);


--
-- Name: vehicle_tracking id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicle_tracking ALTER COLUMN id SET DEFAULT nextval('public.vehicle_tracking_id_seq'::regclass);


--
-- Name: vehicles id; Type: DEFAULT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles ALTER COLUMN id SET DEFAULT nextval('public.vehicles_id_seq'::regclass);


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.drivers (id, user_id, license_number, license_expiry, status, created_at, updated_at, license_type, phone, address, emergency_contact, emergency_phone) FROM stdin;
\.


--
-- Data for Name: fleet_owners; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.fleet_owners (id, user_id, company_name, business_license, address, phone, verified, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.notifications (id, user_id, title, message, type, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: revenue_records; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.revenue_records (id, fleet_owner_id, vehicle_id, trip_date, distance, revenue, expenses, description, created_at) FROM stdin;
\.


--
-- Data for Name: trip_tracking; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.trip_tracking (id, trip_id, latitude, longitude, speed, heading, accuracy, recorded_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.trips (id, driver_id, vehicle_id, origin, destination, departure_time, arrival_time, status, distance, created_at, updated_at, trip_number, origin_address, destination_address, origin_lat, origin_lng, destination_lat, destination_lng, scheduled_start, actual_start, actual_end, distance_km, fuel_used, cargo_weight, cargo_description, trip_fee, driver_fee, notes) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.users (id, username, email, password_hash, full_name, role, created_at, updated_at, user_type) FROM stdin;
3	<script>alert(1)</script>	xss@test.com	$2a$10$3058HMUP24jOa.ajdVCFd.Y64UUKeDFKPAwfsL3NzUz8tsO/52IfW	XSS Test	user	2025-09-11 03:21:24.615439	2025-09-11 03:21:24.615439	customer
4	novan	novandriy4@gmail.com	$2a$10$Ji8pq.Zm6VHU9YLWGA0Gi.B2iLTuX/pIC0xv9WL5G3i6RnSl6K2Wy	novan	user	2025-09-11 03:27:09.747802	2025-09-11 03:27:09.747802	customer
2	admin	admin@tms.com	$2a$10$m9wrm7czgOy712GmUaii1uDZp9Jbd8Iu/utp5D2up0/ugbJzofoUG	Administrator	admin	2025-09-11 02:59:46.868682	2025-09-12 08:55:11.718621	customer
6	driver1	driver1@tms.com	$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	John Driver	driver	2025-09-12 09:06:01.59026	2025-09-12 09:06:01.59026	customer
\.


--
-- Data for Name: vehicle_attachments; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.vehicle_attachments (id, vehicle_id, attachment_type, file_name, file_path, file_size, mime_type, uploaded_at) FROM stdin;
\.


--
-- Data for Name: vehicle_tracking; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.vehicle_tracking (id, vehicle_id, latitude, longitude, speed, status, fuel_level, mileage, last_updated) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: tms_user
--

COPY public.vehicles (id, registration_number, vehicle_type, brand, model, year, chassis_number, engine_number, color, capacity_weight, capacity_volume, ownership_status, operational_status, insurance_company, insurance_policy_number, insurance_expiry_date, last_maintenance_date, next_maintenance_date, maintenance_notes, created_by, created_at, updated_at, fleet_owner_id, verification_status) FROM stdin;
\.


--
-- Name: drivers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.drivers_id_seq', 1, false);


--
-- Name: fleet_owners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.fleet_owners_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: revenue_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.revenue_records_id_seq', 1, false);


--
-- Name: trip_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.trip_tracking_id_seq', 1, false);


--
-- Name: trips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.trips_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: vehicle_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.vehicle_attachments_id_seq', 1, false);


--
-- Name: vehicle_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.vehicle_tracking_id_seq', 1, false);


--
-- Name: vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tms_user
--

SELECT pg_catalog.setval('public.vehicles_id_seq', 1, false);


--
-- Name: drivers drivers_license_number_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_license_number_key UNIQUE (license_number);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: fleet_owners fleet_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.fleet_owners
    ADD CONSTRAINT fleet_owners_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: revenue_records revenue_records_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.revenue_records
    ADD CONSTRAINT revenue_records_pkey PRIMARY KEY (id);


--
-- Name: trip_tracking trip_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.trip_tracking
    ADD CONSTRAINT trip_tracking_pkey PRIMARY KEY (id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: trips trips_trip_number_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_trip_number_key UNIQUE (trip_number);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vehicle_attachments vehicle_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicle_attachments
    ADD CONSTRAINT vehicle_attachments_pkey PRIMARY KEY (id);


--
-- Name: vehicle_tracking vehicle_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicle_tracking
    ADD CONSTRAINT vehicle_tracking_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_chassis_number_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_chassis_number_key UNIQUE (chassis_number);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_registration_number_key; Type: CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_registration_number_key UNIQUE (registration_number);


--
-- Name: idx_drivers_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_drivers_status ON public.drivers USING btree (status);


--
-- Name: idx_trips_departure; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_trips_departure ON public.trips USING btree (departure_time);


--
-- Name: idx_trips_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_trips_status ON public.trips USING btree (status);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_vehicle_attachments_type; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_vehicle_attachments_type ON public.vehicle_attachments USING btree (attachment_type);


--
-- Name: idx_vehicle_attachments_vehicle; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_vehicle_attachments_vehicle ON public.vehicle_attachments USING btree (vehicle_id);


--
-- Name: idx_vehicles_registration; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_vehicles_registration ON public.vehicles USING btree (registration_number);


--
-- Name: idx_vehicles_status; Type: INDEX; Schema: public; Owner: tms_user
--

CREATE INDEX idx_vehicles_status ON public.vehicles USING btree (operational_status);


--
-- Name: drivers drivers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fleet_owners fleet_owners_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.fleet_owners
    ADD CONSTRAINT fleet_owners_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: revenue_records revenue_records_fleet_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.revenue_records
    ADD CONSTRAINT revenue_records_fleet_owner_id_fkey FOREIGN KEY (fleet_owner_id) REFERENCES public.fleet_owners(id) ON DELETE CASCADE;


--
-- Name: revenue_records revenue_records_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.revenue_records
    ADD CONSTRAINT revenue_records_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: trip_tracking trip_tracking_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.trip_tracking
    ADD CONSTRAINT trip_tracking_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id) ON DELETE CASCADE;


--
-- Name: trips trips_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id);


--
-- Name: vehicle_attachments vehicle_attachments_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicle_attachments
    ADD CONSTRAINT vehicle_attachments_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: vehicle_tracking vehicle_tracking_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicle_tracking
    ADD CONSTRAINT vehicle_tracking_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: vehicles vehicles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: vehicles vehicles_fleet_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tms_user
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_fleet_owner_id_fkey FOREIGN KEY (fleet_owner_id) REFERENCES public.fleet_owners(id);


--
-- PostgreSQL database dump complete
--

\unrestrict jeyZuEktfC5i1j9A6aZVfvRXParY2M8lqGKvpK9XKFfs4tzElBsIA6NFD0YvGPx

